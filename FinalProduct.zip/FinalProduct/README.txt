Hello! 

The information in this .zip folder should be anything and everything needed to reproduce a working copy of our paper. 

Proceed as follows:
1. Download this folder.
2. Open the 'HallScript.Rmd' file in the 'Analysis' section.
3. Run it chunk-by-chunk. Pay attention to lines marked **INSTRUCTION**, as they will tell you when to run the .py files found in the same directory.
4. Any .csv files created in your "Data" folder should mirror the paper. Use THIS GUIDE:

	Figures 1-8: Created IN THE PAPER SCRIPT.
	Figure 9: cbbAll.csv
	Figure 10: gamesTo2019.csv (dataset was slightly edited before making this figure -- forgot to include that in the caption.)
	Figure 14: Data/Images/post_model_structure.png
	Figure 15: tournamentFINAL.csv
	Figure 16: gamesTo2021UPDATED.csv
	Figure 17: tourneySimulated.csv

If something was forgot in this repo, you can clone the original repo and follow a similar structure. It can be found at the link below:

https://github.com/halljc76/MarchMadness_STOR320

OVERVIEW
--------
Repo: See above link
Paper: In the 'Paper' folder of this .zip file
Presentation: See the README on the homepage of the Repo

THANKS FOR A GREAT SEMESTER!
Sincerely, 
Group 10
